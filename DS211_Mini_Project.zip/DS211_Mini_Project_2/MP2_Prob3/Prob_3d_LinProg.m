%{
Part of answer 3d:

The following is the code that utilises the 
the linprog function of matlab to solve the 
given linear program.


Ref: https://in.mathworks.com/help/optim/ug/linprog.html#buusznx-3
%}

%Defining coeffecient matrix of 'equality' constraints
A = zeros(7,18);
A(1,1) = 1.005;
A(1,2) = 1.005;
A(1,3) = -.02;
A(1,4) = -1;

A(2,2) = -1.036;
A(2,4) = 1.005;
A(2,5) = 1.005;
A(2,6) = -.02;
A(2,7) = -1;

A(3,5) = -1.036;
A(3,7) = 1.005;
A(3,8) = 1.005;
A(3,9) = -.02;
A(3,10) = -1;

A(4,8) = -1.036;
A(4,10) = 1.005;
A(4,11) = -1;

A(5,11) = 1.010025;
A(5,12) = 1.005;
A(5,13) = -.02;
A(5,14) = -1;

A(6,12) = -1.036;
A(6,14) = 1.005;
A(6,15)= 1.005;
A(6,16)= -.02;
A(6,17) = -1;

A(7,1) = -1.08;
A(7,15) = -1.036;
A(7,17) = 1.005;
A(7,18) = -1  ;

% Defining rhs of equality constraints
b = [100.5; 502.5; 100.5; -600; -301.5; 603; -900];

% Defining cost vector
c = zeros(18,1);
c(18,1) = -1;

% Defining coeff matrix and rhs for inequality constraints
Ain =[];
bin =[];

% Defining lower bound for all variables as 0. 
% There is no upper bound.
lb = zeros(size(c));
ub = [];

% Defining method of solving the linear program as 'dual-simplex'
option1 = optimoptions('linprog','Algorithm','dual-simplex');
option2 = optimoptions('linprog','Algorithm','interior-point');


tic
% Solving the linear program using dual-simplex method
[x_ds, fval_ds, exitflag_ds, output_ds] = linprog(c, Ain, bin, A, b, lb, ub, option1);
t1 = toc;


tic
% Solving the linear program using interior-point method
[x_ip, fval_ip, exitflag_ip, output_ip] = linprog(c, Ain, bin, A, b, lb, ub, option2);
t2 = toc;

disp('-------Solution for Dual-Simplex Method--------')
disp('Solution:')
disp(x_ds')
disp('Additional Information:')
disp(output_ds)
disp('Compute time (secs): ')
disp(t1)

disp('-------Solution forInterior-Point Method--------')
disp('Solution:')
disp(x_ip')
disp('Additional Information:')
disp(output_ip)
disp('Compute time (secs): ')
disp(t2)
